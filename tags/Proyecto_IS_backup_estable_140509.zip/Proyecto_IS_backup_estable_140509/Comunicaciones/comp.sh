#!/bin/bash
javac -cp src src/clienteegorilla/ClienteTest.java -d build & \
javac -cp src src/servidoregorilla/Main.java -d build
