#!/bin/bash
javac -cp src src/servidoregorilla/Main.java -d build
