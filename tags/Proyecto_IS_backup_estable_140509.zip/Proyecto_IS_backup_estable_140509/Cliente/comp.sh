#!/bin/bash
javac -cp src src/clienteegorilla/ClienteTest.java -d build
