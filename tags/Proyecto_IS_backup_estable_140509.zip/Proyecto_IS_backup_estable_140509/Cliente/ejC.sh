#!/bin/bash
java -cp build clienteegorilla.ClienteTest
