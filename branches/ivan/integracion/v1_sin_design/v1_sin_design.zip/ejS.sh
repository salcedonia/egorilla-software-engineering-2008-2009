#!/bin/bash
java -cp build servidoregorilla.Main
