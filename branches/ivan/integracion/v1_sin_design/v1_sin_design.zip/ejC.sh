#!/bin/bash
java -cp build clienteTest.ClienteTest
