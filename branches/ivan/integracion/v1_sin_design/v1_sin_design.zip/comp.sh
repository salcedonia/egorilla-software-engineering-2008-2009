#!/bin/bash
javac -cp src src/clienteTest/ClienteTest.java -d build & javac -cp src src/servidoregorilla/Main.java -d build
